# StoryAppSub2
 Submission 2 for Intermediate Android Dicoding Course
