package com.dicoding.storyapp.data.remote

import android.content.Context
import androidx.paging.PagingSource
import androidx.paging.PagingState
import androidx.room.Room
import com.dicoding.storyapp.data.remote.response.ListStoryItem
import com.dicoding.storyapp.data.room.StoryDatabase
import com.dicoding.storyapp.ui.viewmodel.ListStoryViewModel

class StoryPagingSource(private val storyViewModel: ListStoryViewModel, private val context: Context) : PagingSource<Int, ListStoryItem>() {
  private var stories: MutableList<ListStoryItem> = mutableListOf()

  override fun getRefreshKey(state: PagingState<Int, ListStoryItem>): Int? {
    return state.anchorPosition?.let { anchorPosition ->
      val anchorPage = state.closestPageToPosition(anchorPosition)
      anchorPage?.prevKey?.plus(1) ?: anchorPage?.nextKey?.minus(1)
    }
  }

  val database = Room.databaseBuilder(
    context.applicationContext, StoryDatabase::class.java,
    "story.db"
  ).build()

  override suspend fun load(params: LoadParams<Int>): LoadResult<Int, ListStoryItem> {
    return try {
      val position = params.key ?: INITIAL_PAGE_INDEX
//      val responseData = storyViewModel.getStory("token")

      database.storyDao().getStory().forEach{
        stories.add(
          ListStoryItem(
            it.photoUrl,
            it.createdAt,
            it.name,
            it.description,
            it.id
          )
        )
      }

      val responseData = stories.first()
      LoadResult.Page(
        data = listOf(responseData),
        prevKey = if (position == INITIAL_PAGE_INDEX) null else position - 1,
        nextKey = position + 1
      )
    } catch (exception: Exception) {
      return LoadResult.Error(exception)
    }
  }

  private companion object {
    const val INITIAL_PAGE_INDEX = 1
  }
}