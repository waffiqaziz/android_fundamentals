package com.dicoding.storyapp.data

import com.dicoding.storyapp.data.remote.response.AllStoriesResponse
import com.dicoding.storyapp.data.remote.retrofit.ApiService
import com.dicoding.storyapp.data.room.StoryDao
import com.dicoding.storyapp.helper.Helper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class StoryRepository(
  private val storyDao: StoryDao,
  private val apiService: ApiService,
) {

  suspend fun getStories(token: String): Flow<Helper.ResultResponse<AllStoriesResponse>> {
    return flow {
      try {
        emit(Helper.ResultResponse.LOADING)
        val response = apiService.getAllStories("Bearer $token")
        if (!response.error) {
          storyDao.deleteAll()
          val storyList = response.listStory.map {
            Helper.storyEntity(it)
          }
          storyDao.insertStory(storyList)
          emit(Helper.ResultResponse.SUCCESS(response))
        } else {
          emit(Helper.ResultResponse.ERROR(response.message))
        }
      } catch (e: Exception) {
        emit(Helper.ResultResponse.ERROR(e.message.toString()))
      }
    }
  }
}