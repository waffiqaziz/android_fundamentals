package com.dicoding.storyapp.ui.viewmodel

import android.content.Context
import androidx.lifecycle.*
import com.dicoding.storyapp.data.StoryRepository
import com.dicoding.storyapp.data.remote.response.AllStoriesResponse
import com.dicoding.storyapp.di.Injection
import com.dicoding.storyapp.helper.Helper
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class ListStoryViewModel (private val storyRepository: StoryRepository) : ViewModel() {
  private val _itemStory = MutableLiveData<Helper.ResultResponse<AllStoriesResponse>>()

  fun getStory(token: String) : LiveData<Helper.ResultResponse<AllStoriesResponse>> {
    viewModelScope.launch {
      storyRepository.getStories(token).collect {
        _itemStory.postValue(it)
      }
    }
    return _itemStory
  }
}

class ListViewModelFactory(private val context: Context) :
  ViewModelProvider.Factory {
  override fun <T : ViewModel> create(modelClass: Class<T>): T {
    if (modelClass.isAssignableFrom(ListStoryViewModel::class.java)) {
      @Suppress("UNCHECKED_CAST")
      return ListStoryViewModel(Injection.provideRepository(context)) as T
    }
    throw IllegalArgumentException("Unknown ViewModel class")
  }
}
