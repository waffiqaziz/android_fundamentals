package com.dicoding.storyapp.data.room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.dicoding.storyapp.data.remote.response.ListStoryItem

@Dao
interface StoryDao {
  @Query("SELECT * FROM story")
  fun getStory(): List<ListStoryItem>

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertStory(storyEntity: List<ListStoryItem>)

  @Query("DELETE FROM story")
  suspend fun deleteAll()
}