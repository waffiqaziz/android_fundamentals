package com.dicoding.storyapp.ui.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.storyapp.data.model.UserModel
import com.dicoding.storyapp.databinding.ActivityListStoryBinding
import com.dicoding.storyapp.helper.Helper
import com.dicoding.storyapp.ui.adapter.StoryAdapter
import com.dicoding.storyapp.ui.viewmodel.ListStoryViewModel
import com.dicoding.storyapp.ui.viewmodel.ListViewModelFactory


class ListStoryActivity : AppCompatActivity() {

  private var _binding: ActivityListStoryBinding? = null
  private val binding get() = _binding

  private lateinit var user: UserModel
  private lateinit var adapter: StoryAdapter

  private val viewModel:ListStoryViewModel by viewModels{
    ListViewModelFactory(this)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    _binding = ActivityListStoryBinding.inflate(layoutInflater)
    setContentView(binding?.root)

    setupToolbar()
    addStoryAction()

    user = intent.getParcelableExtra(EXTRA_USER)!!

    getData()
    adapter = StoryAdapter()

    setupRecycleView()
  }

  private fun setupToolbar(){
    setSupportActionBar(binding?.toolbar)
    supportActionBar?.setDisplayHomeAsUpEnabled(true)
    supportActionBar?.setDisplayShowHomeEnabled(true)
  }

  override fun onSupportNavigateUp(): Boolean {
    onBackPressed()
    return true
  }

  private fun getData() {
    viewModel.getStory(user.token).observe(this) {
      when (it) {
        is Helper.ResultResponse.LOADING -> showLoading(true)
        is Helper.ResultResponse.SUCCESS -> {
          showLoading(false)
          adapter.submitList(it.data.listStory)
        }
        is Helper.ResultResponse.ERROR -> showLoading(false)
        else -> {
          Log.e("ERROR MESSAGE","ERROR")
        }
      }
    }
  }

  private fun setupRecycleView(){
    binding?.rvStory?.layoutManager = LinearLayoutManager(this)
    binding?.rvStory?.setHasFixedSize(true)
    binding?.rvStory?.adapter = adapter
  }

  private fun showLoading(it: Boolean) {
    binding?.apply {
      if (it) {
        progressBar.visibility = View.VISIBLE
        rvStory.visibility = View.GONE
        tvInfo.visibility = View.GONE
      } else {
        tvInfo.visibility = View.GONE
        rvStory.visibility = View.VISIBLE
        progressBar.visibility = View.GONE
      }
    }
  }

  override fun onResume(){
    super.onResume()
    getData()
  }

  override fun onDestroy() {
    super.onDestroy()
    _binding = null
  }

  private fun addStoryAction(){
    binding?.ivAddStory?.setOnClickListener {
      val moveToAddStoryActivity = Intent(this, AddStoryActivity::class.java)
      moveToAddStoryActivity.putExtra(AddStoryActivity.EXTRA_USER, user)
      startActivity(moveToAddStoryActivity)
    }
  }

  companion object {
    const val EXTRA_USER = "user"
  }
}