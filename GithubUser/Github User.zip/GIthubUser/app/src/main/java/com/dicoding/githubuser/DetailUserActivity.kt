package com.dicoding.githubuser

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class DetailUserActivity : AppCompatActivity() {
  companion object {
    const val EXTRA_USER = "user"
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_detail_user)
    supportActionBar?.title = "Detail User"

    val tvFollowers: TextView = findViewById(R.id.tv_followers)
    val tvFollowing: TextView = findViewById(R.id.tv_following)
    val tvName: TextView = findViewById(R.id.tv_name)
    val tvUsername: TextView = findViewById(R.id.tv_username)
    val tvCompany: TextView = findViewById(R.id.tv_company)
    val tvRepository: TextView = findViewById(R.id.tv_repository)
    val tvLocation: TextView = findViewById(R.id.tv_location)
    val ivBack: ImageView = findViewById(R.id.iv_back)
    val ivAvatar: ImageView = findViewById(R.id.iv_avatar)

    ivBack.setOnClickListener {
      val intent = Intent(this@DetailUserActivity, MainActivity::class.java)
      startActivity(intent)
      finish()
    }

    val user = intent.getParcelableExtra<User>(EXTRA_USER) as User
    tvFollowers.text = user.followers
    tvFollowing.text = user.following
    tvName.text = user.name
    tvUsername.text = user.username
    tvCompany.text = user.company
    tvRepository.text = user.repository
    tvLocation.text = user.location
    Glide.with(ivAvatar)
      .load(user.avatar) // URL Avatar
      .circleCrop() // Mengubah avatar menjadi lingkaran
      .into(ivAvatar)
  }
}